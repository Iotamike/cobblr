
from time import sleep
from cobblr import CobblrBroker


def broker_main():

    broker = CobblrBroker()

    # This is the main program loop which is up to the user to define
    # At the moment, get_connected_clients is the only user function
    while True:

        # I've put a long delay on the loop for debugging
        # Response times are in ms for the program
        sleep(10)

        # Get all connected clients and print
        # get_connected_clients() returns a list
        clients = broker.get_connected_clients()
        print("Connected clients:")
        try:
            for client in clients[1:]:
                print(client)
        except IndexError:
            print("Error: no connected clients")


broker_main()




