
from time import sleep
from cobblr import CobblrClient


def output_main():

    # create a new CobblrClient with the passed name
    # you can create multiple CobblrClients in a single python script
    output = CobblrClient("output")

    # You need to register your CobblrClient with the broker
    output.register()

    # wait while all the other apps are registering
    # I'll remove the need for this delay in future versions
    sleep(2)

    # request a connection to the named CobblrClient
    # once ONE client has requested the connection -
    # BOTH clients can communicate with each other
    # by name addressing
    output.request_connection("analysis")

    # This is the main program loop which is up to the user to define
    while True:

        # I've put a long delay on the loop for debugging
        # Response times are in ms for the program
        sleep(10)

        # Get all connected clients and print
        # get_connected_clients() returns a list
        clients = output.get_connected()
        print("Connected clients:")
        try:
            for client in clients[1:]:
                print(client)
        except IndexError:
            print("Error: no connected clients")

        # Get all messages in the 'inbox' and print
        # get_messages returns a tab "\t" separated list
        # each message is in the form:
        # "sender_name", "message_string1", "message_string2", ... , "\t",
        messages = output.get_messages()
        print(messages)

        output.send_message("analysis", ["RESULT"])


output_main()
